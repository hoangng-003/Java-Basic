public class Circle extends Shape {
  protected double radius;
  public static final double PI = 3.14;

  public Circle() {
  }

  public Circle(double radius) {
    this.radius = radius;
  }

  public Circle(double radius, String color, boolean filled) {
    super(color, filled);
    this.radius = radius;
  }

  public double getRadius() {
    return this.radius;
  }

  public void setRadius(double radius) {
    this.radius = radius;
  }

  public String toString() {
    return "Circle[" + "radius=" + radius + ",color=" + super.color + ",filled=" + super.filled + "]";
  }

  public double getArea() {
    return PI * radius * radius;
  }

  public double getPerimeter() {
    return 2 * PI * radius;
  }

}
